import React from "react";
import "../styles/Technologies.css";

const Technologies = () => {
  return (
    <>
      <div className="technologies-section">
        {/* Aquí va tu contenido */}
      </div>
    </>
  );
};

export default Technologies;
