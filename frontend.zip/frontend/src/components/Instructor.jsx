import React from "react";
import "../styles/Instructor.css";

const Instructor = () => {
  return (
    <div className="instructor-page">
      <div className="instructor-card">
        {/* Aquí va tu contenido */}
      </div>
    </div>
  );
};

export default Instructor;
