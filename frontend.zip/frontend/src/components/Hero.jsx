import React, { useContext } from "react";
import "../styles/Hero.css";
import { Context } from "../main";

const Hero = () => {
  const { user } = useContext(Context);
  return (
    <>
      <div className="hero-section">
        {/* Aquí va tu contenido */}
      </div>
    </>
  );
};

export default Hero;
